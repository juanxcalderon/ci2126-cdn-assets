#include <cs50.h>
#include <stdio.h>
#include <string.h>

int separar_letras(string texto, char letras[][5]);

int main(int argc, string argv[])
{

}

// Separa el texto en letras completas y las guarda en el arreglo "letras",
// una por casilla (incluidas la ñ, las letras con tilde, ¡, ¿ y otros símbolos).
// Devuelve cuántas letras hay en el texto.
// No necesita entender cómo funciona por dentro: solo úsela. ¡No la modifique!
int separar_letras(string texto, char letras[][5])
{
    int total = 0;
    int n = strlen(texto);
    int i = 0;
    while (i < n)
    {
        // El primer valor de cada letra indica cuántas casillas del string ocupa
        int primero = (unsigned char) texto[i];
        int casillas = 1;
        if (primero >= 240)
        {
            casillas = 4;
        }
        else if (primero >= 224)
        {
            casillas = 3;
        }
        else if (primero >= 192)
        {
            casillas = 2;
        }

        // Copiamos esas casillas juntas, como una sola letra
        for (int j = 0; j < casillas && i + j < n; j++)
        {
            letras[total][j] = texto[i + j];
            letras[total][j + 1] = '\0';
        }
        i += casillas;
        total++;
    }
    return total;
}
