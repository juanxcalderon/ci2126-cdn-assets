import csv
import sys


def main():

    # POR HACER: Verificar el uso de la línea de comandos

    # POR HACER: Leer el archivo de la base de datos en una variable
    
    # POR HACER: Leer el archivo de la secuencia de ADN en una variable

    # POR HACER: Encontrar la cadena de repeticiones consecutivas más larga de cada STR en la secuencia de ADN

    # POR HACER: Revisar la base de datos en busca de perfiles coincidentes

    return


def coincidencia_mas_larga(secuencia, subsecuencia):
    """Devuelve la longitud de la cadena de repetición más larga de la subsecuencia STR en la secuencia de ADN."""

    # Inicializar variables
    max_repeticiones = 0
    longitud_subsecuencia = len(subsecuencia)
    longitud_secuencia = len(secuencia)

    # Revisar cada carácter en la secuencia para encontrar las cadenas de repeticiones consecutivas más largas de la subsecuencia STR
    for i in range(longitud_secuencia):

        # Inicializar el conteo de repeticiones consecutivas
        conteo = 0

        # Verifica si hay una coincidencia de la subsecuencia STR en un "substring" dentro de la secuencia de ADN.
        # Si hay coincidencia, mueve el substring a la siguiente coincidencia potencial en la secuencia.
        # Continúa moviendo el substring y verificando coincidencias hasta que no haya más repeticiones consecutivas.
        while True:

            # Ajusta el inicio y el fin del substring
            inicio = i + conteo * longitud_subsecuencia
            fin = inicio + longitud_subsecuencia

            # Si hay una coincidencia en el substring
            if secuencia[inicio:fin] == subsecuencia:
                conteo += 1
            
            # Si no hay coincidencia en el substring
            else:
                break
        
        # Actualiza la mayor cantidad de repeticiones consecutivas de la subsecuencia STR encontradas
        max_repeticiones = max(max_repeticiones, conteo)

    # Después de revisar las repeticiones en cada carácter de la secuencia, devolver la cadena de repetición consecutiva más larga encontrada.
    return max_repeticiones


main()