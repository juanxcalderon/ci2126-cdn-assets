// Declara la funcionalidad de un diccionario

#ifndef DICCIONARIO_H
#define DICCIONARIO_H

#include <stdbool.h>

// Longitud máxima para una palabra
// (por ejemplo, pneumonoultramicroscopicsilicovolcanoconiosis)
#define LENGTH 45

// Prototipos
bool check(const char *word);
unsigned int hash(const char *word);
bool load(const char *DICCIONARIO);
unsigned int size(void);
bool unload(void);

#endif // DICCIONARIO_H