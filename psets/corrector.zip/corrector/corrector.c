// Implementa un corrector ortográfico
#include <ctype.h>
#include <stdio.h>
#include <sys/resource.h>
#include <sys/time.h>

#include "diccionario.h"

// Anula cualquier definición previa
#undef calculo_segundos
#undef getrusage

// Diccionario por defecto
#define DICCIONARIO "diccionarios/grande"

// Prototipo
double calculo_segundos(const struct rusage *b, const struct rusage *a);


int main(int argc, char *argv[])
{
    // Verifica la cantidad correcta de argumentos
    if (argc != 2 && argc != 3)
    {
        printf("Uso: ./corrector [DICCIONARIO] texto\n");
        return 1;
    }

    // Estructuras para medir tiempos
    struct rusage before, after;

    // Variables para medir tiempos de ejecución
    double time_load = 0.0, time_check = 0.0, time_size = 0.0, time_unload = 0.0;

    // Determina qué diccionario usar
    char *diccionario = (argc == 3) ? argv[1] : DICCIONARIO;

    // Carga el diccionario
    getrusage(RUSAGE_SELF, &before);
    bool loaded = load(diccionario);
    getrusage(RUSAGE_SELF, &after);

    // Sale si no se pudo cargar el diccionario
    if (!loaded)
    {
        printf("No se pudo cargar %s.\n", diccionario);
        return 1;
    }

    // Calcula el tiempo que tomó cargar el diccionario
    time_load = calculo_segundos(&before, &after);

    // Intenta abrir el archivo de texto
    char *text = (argc == 3) ? argv[2] : argv[1];
    FILE *file = fopen(text, "r");
    if (file == NULL)
    {
        printf("No se pudo abrir %s.\n", text);
        unload();
        return 1;
    }

    // Prepara para mostrar palabras mal escritas
    printf("\nPALABRAS MAL ESCRITAS\n\n");

    // Prepara para realizar el chequeo ortográfico
    int index = 0, misspellings = 0, words = 0;
    char word[LENGTH + 1];

    // Chequea palabra por palabra en el texto
    char c;
    while (fread(&c, sizeof(char), 1, file))
    {
        // Permite solo caracteres alfabéticos y apóstrofos
        if (isalpha(c) || (c == '\'' && index > 0))
        {
            // Añade el carácter a la palabra
            word[index] = c;
            index++;

            // Ignora cadenas alfabéticas demasiado largas para ser palabras
            if (index > LENGTH)
            {
                // Consume el resto de la cadena alfabética
                while (fread(&c, sizeof(char), 1, file) && isalpha(c));

                // Prepara para nueva palabra
                index = 0;
            }
        }

        // Ignora palabras con números (como hace Microsoft Word)
        else if (isdigit(c))
        {
            // Consume el resto de la cadena alfanumérica
            while (fread(&c, sizeof(char), 1, file) && isalnum(c));

            // Prepara para nueva palabra
            index = 0;
        }

        // Debe haber encontrado una palabra completa
        else if (index > 0)
        {
            // Termina la palabra actual
            word[index] = '\0';

            // Actualiza el contador
            words++;

            // Verifica la ortografía de la palabra
            getrusage(RUSAGE_SELF, &before);
            bool misspelled = !check(word);
            getrusage(RUSAGE_SELF, &after);

            // Actualiza la medición de tiempo
            time_check += calculo_segundos(&before, &after);

            // Muestra la palabra si está mal escrita
            if (misspelled)
            {
                printf("%s\n", word);
                misspellings++;
            }

            // Prepara para la siguiente palabra
            index = 0;
        }
    }

    // Verifica si hubo algún error
    if (ferror(file))
    {
        fclose(file);
        printf("Error leyendo %s.\n", text);
        unload();
        return 1;
    }

    // Cierra el archivo de texto
    fclose(file);

    // Determina el tamaño del diccionario
    getrusage(RUSAGE_SELF, &before);
    unsigned int n = size();
    getrusage(RUSAGE_SELF, &after);

    // Calcula el tiempo para obtener el tamaño del diccionario
    time_size = calculo_segundos(&before, &after);

    // Descarga el diccionario
    getrusage(RUSAGE_SELF, &before);
    bool unloaded = unload();
    getrusage(RUSAGE_SELF, &after);

    // Aborta si no se pudo descargar el diccionario
    if (!unloaded)
    {
        printf("No se pudo descargar %s.\n", diccionario);
        return 1;
    }

    // Calcula el tiempo que tomó descargar el diccionario
    time_unload = calculo_segundos(&before, &after);

    // Muestra los resultados
    printf("\nPALABRAS MAL ESCRITAS:     %d\n", misspellings);
    printf("PALABRAS EN EL DICCIONARIO:  %d\n", n);
    printf("PALABRAS EN EL TEXTO:        %d\n", words);
    printf("TIEMPO DE EJECUCIÓN DE load:         %.2f\n", time_load);
    printf("TIEMPO DE EJECUCIÓN DE check:        %.2f\n", time_check);
    printf("TIEMPO DE EJECUCIÓN DE size:         %.2f\n", time_size);
    printf("TIEMPO DE EJECUCIÓN DE unload:       %.2f\n", time_unload);
    printf("TIEMPO TOTAL:           %.2f\n\n",
           time_load + time_check + time_size + time_unload);

    // Éxito
    return 0;
}


// Devuelve el número de segundos entre b y a
double calculo_segundos(const struct rusage *b, const struct rusage *a)
{
    if (b == NULL || a == NULL)
    {
        return 0.0;
    }
    else
    {
        return ((((a->ru_utime.tv_sec * 1000000 + a->ru_utime.tv_usec) -
                  (b->ru_utime.tv_sec * 1000000 + b->ru_utime.tv_usec)) +
                 ((a->ru_stime.tv_sec * 1000000 + a->ru_stime.tv_usec) -
                  (b->ru_stime.tv_sec * 1000000 + b->ru_stime.tv_usec)))
                / 1000000.0);
    }
}