// Implementa la funcionalidad de un diccionario

#include <ctype.h>
#include <stdbool.h>

#include "diccionario.h"

// Representa un nodo en una tabla hash
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
} node;


// POR HACER: Elegir la cantidad de "cubetas" en la tabla hash
const unsigned int N = ;


// Tabla hash
node *table[N];


// Devuelve true si la palabra está en el diccionario, de lo contrario false
bool check(const char *word)
{
    // POR HACER
    return false;
}


// Convierte una palabra en un número (función hash)
unsigned int hash(const char *word)
{
    // POR HACER: Mejorar esta función hash
    return toupper(word[0]) - 'A';
}


// Carga el diccionario en memoria, devuelve true si es exitoso, de lo contrario false
bool load(const char *diccionario)
{
    // POR HACER
    return false;
}


// Devuelve la cantidad de palabras en el diccionario si fue cargado, de lo contrario 0
unsigned int size(void)
{
    // POR HACER
    return 0;
}


// Descarga el diccionario de la memoria, devuelve true si es exitoso, de lo contrario false
bool unload(void)
{
    // POR HACER
    return false;
}