#include <cs50.h>
#include <stdio.h>

// Se define dos variables constantes: Máximo de votantes y Máximo de candidatos
#define MAX_VOTANTES 10000
#define MAX_CANDIDATOS 10

// Se define la matriz "resultado_eleccion[i][j]", donde la fila i representa a un sector universitario
// y cada columna j representa a uno de los candidatos de la elección a rector. Cada casilla representa
// entonces la cantidad de votos YA PONDERADOS que ha recibido cada candidato j del sector i.
int resultado_eleccion[4][MAX_CANDIDATOS];

// Se define el tipo abstracto de datos "candidato", donde se especifica
// el nombre, los votos recolectados por cada sector, y la variable eliminado, 
// para especificar si pasa a la segunda ronda o no.
typedef struct
{
    string nombre_candidato;
    int votos_profesores;
	int votos_estudiantes;
	int votos_egresados;
	int votos_empleados;
	int votos_obreros;
    bool eliminado;
	
} candidato;

// Se define el arreglo "lista_candidatos" donde se almacenan los candidatos especificados 
// por el usuario para la elección universitaria de rector.
candidato lista_candidatos[MAX_CANDIDATOS];

// Variable para almacenar el número de candidatos
int contador_candidatos;

// Prototipo de funciones y procedimientos auxiliares
bool conteo_votos_candidato(int voter, int rank, string name);
void totalizacion_resultado(void);
bool imprimir_ganador(void);
bool segunda_ronda(void);



//Función principal "elecciones"
int main(int argc, string argv[])
{
    // Revisión de invocación correcta del programa por parte del usuario,
	// que haya suministrado los mínimos argumentos solicitados.
    if (argc < 2)
    {
        printf("Uso correcto: elecciones [candidato ...]\n");
        return 1;
    }

    // Llenar el arreglo "lista_candidatos" con los candidatos especificados por el usuario.
    contador_candidatos = argc - 1;
    if (contador_candidatos > MAX_CANDIDATOS)
    {
        printf("El número máximo de candidatos para la elección es %i\n", MAX_CANDIDATOS);
        return 2;
    }
    for (int i = 0; i < contador_candidatos; i++)
    {
        lista_candidatos[i].nombre_candidato = argv[i + 1];
        lista_candidatos[i].votos_profesores = 0;
		lista_candidatos[i].votos_estudiantes = 0;
		lista_candidatos[i].votos_egresados = 0;
		lista_candidatos[i].votos_empleados = 0;
		lista_candidatos[i].votos_obreros = 0;
        lista_candidatos[i].eliminado = false;
    }

    // Se recaban los votos obtenidos por cada candidato en cada uno de los cinco sectores universitarios.
	// i = 0 (Sector Profesoral)
	// i = 1 (Sector Estudiantil)
	// i = 2 (Sector de Egresados)
	// i = 3 (Sector Administrativo y Técnico)
	// i = 4 (Sector Obrero)
    for (int i = 0; i < 5; i++)
    {
		
		switch (i)
		{
			case 0:
				printf("SECTOR PROFESORAL:\n");
				break;
				
			case 1:
				printf("SECTOR ESTUDIANTIL:\n");
				break;
				
			case 2:
				printf("SECTOR DE EGRESADOS:\n");
				break;
				
			case 3:
				printf("SECTOR ADMINISTRATIVO Y TÉCNICO:\n");
				break;
			
			case 4:
				printf("SECTOR OBREROS:\n");
				break;
		}
		

        // Revisión de los votos obtenidos por cada uno de los candidatos especificados
		// dentro de un sector particular. 
        for (int j = 0; j < contador_candidatos; j++)
        {
            string votos_sector = get_string("- %s: ", lista_candidatos[j].nombre_candidato);

            // Se hace totalización de votos. Para el sector i, se guarda 
			//en el candidato j los votos que recolectó en ese sector.
            if (!conteo_votos_candidato(i, j, votos_sector))
            {
                printf("Dato introducido inválido.\n");
                return 4;
            }
        }

        printf("\n");

    }

	// Realiza la totalización de los votos obtenidos por cada candidato en cada sector universitario
	// y los pondera de acuerdo a lo establecido en el Reglamento Electoral de la USB, colocando
	// los resultados YA PONDERADOS en el arreglo bidimensional "resultado_eleccion" que está 
	// declarado como variable global.
	totalizacion_resultado();

	// Se revisa, una vez totalizado los resultados, si hay un candidato que haya reunido 
	// la cantidad de votos ponderados estipulado por el Reglamento Electoral de la USB para
	// ser declarado ganador. En caso de haberlo, se muestra en pantalla y termina el programa.
	bool ganador = imprimir_ganador();
	
	if (ganador)
	{
		break;
	}

	// Si la función "imprimir_ganador" no arroja ningún resultado, se asume que se debe
	// ir a una segunda ronda, por lo cual se invoca a la función que determinará, siguiendo
	// lo establecido en el Reglamento Electoral de la USB, cuales son los candidatos que quedaron en
	// los dos primeros lugares de la votación para pasar a una segunda ronda electoral. Los mismos
	// son mostrados en pantalla con el mensaje respectivo de declaración de segunda vuelta
	// electoral y termina el programa.
	bool no_hay_ganador = segunda_ronda();
	
	if (no_hay_ganador)
	{
		break;
	}

    return 0;
}



// Registra en una instancia del Tipo Abstracto de Dato "candidato" 
// los votos recabados por el mismo en un sector universitario en particular.
// En caso de realizar la operación exitosamente, devuelve true; caso contrario,
// devuelve el valor false.
bool conteo_votos_candidato(int sector_universitario, int candidato, string numero_votos)
{
    // POR HACER
    return false;
}


// Realiza la totalización de los votos obtenidos por cada candidato en cada sector universitario
// y los pondera de acuerdo a los procentajes y fórmulas establecidos en el Reglamento Electoral de la USB, 
// colocando los resultados YA PONDERADOS en el arreglo bidimensional "resultado_eleccion" que está 
// declarado como variable global, para que esté a disposición de otras funciones y procedimientos.
void totalizacion_resultado(void)
{
    // POR HACER
    return;
}


// Revisa, previa totalización de los resultados en la variable global "resultado_eleccion", 
// si hay un candidato que haya reunido la cantidad de votos ponderados estipulado por 
// el Reglamento Electoral de la USB para ser declarado ganador. En caso de haberlo, 
// muestra el resultado en pantalla y devuelve true.
bool imprimir_ganador(void)
{
    // POR HACER
    return false;
}


// Función que determina, siguiendo lo establecido en el Reglamento Electoral de la USB, 
// cuales son los candidatos que quedaron en los dos primeros lugares de la votación para 
// pasar a una segunda ronda electoral, marcando como eliminados a los restantes candidatos. 
// Los candidatos que van a segunda ronda son mostrados en pantalla con el mensaje respectivo  
// de declaración de segunda vuelta electoral.
//
// NOTA: Si hay candidatos con una misma cantidad de votos en el primer o segundo lugar de la  
// votación, se mostrarán todos ellos en pantalla. Esto implica que si, por ejemplo, hay un candidato 
// que quedó en primer lugar en votos ponderados, pero en segundo lugar hay dos candidatos con 
// exactamente la misma cantidad de votos ponderados, ambos deben ser mostrados también en pantalla, 
// por lo que serían en total tres (3) candidatos a pasar a la segunda ronda y que tienen que ser
// mostrados en pantalla.
bool segunda_ronda(int min)
{
    // POR HACER
    return false;
}


