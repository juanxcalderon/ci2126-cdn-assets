#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>

#include "efectosvisuales.h"

int main(int argc, char *argv[])
{
    // Variable auxiliar donde se establece los filtros permitidos, en este caso cinco.
    char *filters = "bgrsn";

    // Obtiene la bandera del filtro y verifica su validez contra la variable auxiliar filters
    char filter = getopt(argc, argv, filters);
    if (filter == '?')
    {
        printf("Invalid filter.\n");
        return 1;
    }

    // Asegura que solo se use un filtro
    if (getopt(argc, argv, filters) != -1)
    {
        printf("Only one filter allowed.\n");
        return 2;
    }

    // Asegura el uso correcto de los argumentos
    if (argc != optind + 2)
    {
        printf("Usage: ./filter [flag] infile outfile\n");
        return 3;
    }

    // Recuerda los nombres de los archivos
    char *infile = argv[optind];
    char *outfile = argv[optind + 1];

    // Abre el archivo de entrada
    FILE *inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        printf("Could not open %s.\n", infile);
        return 4;
    }

    // Abre el archivo de salida
    FILE *outptr = fopen(outfile, "w");
    if (outptr == NULL)
    {
        fclose(inptr);
        printf("Could not create %s.\n", outfile);
        return 5;
    }

    // Lee el BITMAPFILEHEADER del archivo de entrada
    BITMAPFILEHEADER bf;
    fread(&bf, sizeof(BITMAPFILEHEADER), 1, inptr);

    // Lee el BITMAPINFOHEADER del archivo de entrada
    BITMAPINFOHEADER bi;
    fread(&bi, sizeof(BITMAPINFOHEADER), 1, inptr);

    // Asegura que el archivo de entrada sea (probablemente) un BMP 4.0 de 24 bits sin compresión
    if (bf.bfType != 0x4d42 || bf.bfOffBits != 54 || bi.biSize != 40 ||
        bi.biBitCount != 24 || bi.biCompression != 0)
    {
        fclose(outptr);
        fclose(inptr);
        printf("Unsupported file format.\n");
        return 6;
    }

    // Obtiene las dimensiones de la imagen
    int height = abs(bi.biHeight);
    int width = bi.biWidth;

    // Asigna memoria para la imagen
    RGBTRIPLE(*image)[width] = calloc(height, width * sizeof(RGBTRIPLE));
    if (image == NULL)
    {
        printf("Not enough memory to store image.\n");
        fclose(outptr);
        fclose(inptr);
        return 7;
    }

    // Determina el relleno (padding) para las líneas de escaneo (scanlines)
    int padding = (4 - (width * sizeof(RGBTRIPLE)) % 4) % 4;

    // Itera sobre las líneas de escaneo del archivo de entrada
    for (int i = 0; i < height; i++)
    {
        // Lee la fila en el arreglo de píxeles
        fread(image[i], sizeof(RGBTRIPLE), width, inptr);

        // Omite el relleno (padding)
        fseek(inptr, padding, SEEK_CUR);
    }

    // Filtra la imagen
    switch (filter)
    {
        // Desenfocar (Blur)
        case 'b':
            blur(height, width, image);
            break;

        // Escala de grises (Grayscale)
        case 'g':
            grayscale(height, width, image);
            break;

        // Reflejo (Reflection)
        case 'r':
            reflect(height, width, image);
            break;

        // Sepia
        case 's':
            sepia(height, width, image);
            break;
			
        // Negativo (Negative)
        case 'n':
            negative(height, width, image);
            break;
			
    }

    // Escribe el BITMAPFILEHEADER del archivo de salida
    fwrite(&bf, sizeof(BITMAPFILEHEADER), 1, outptr);

    // Escribe el BITMAPINFOHEADER del archivo de salida
    fwrite(&bi, sizeof(BITMAPINFOHEADER), 1, outptr);

    // Escribe los nuevos píxeles en el archivo de salida
    for (int i = 0; i < height; i++)
    {
        // Escribe la fila en el archivo de salida
        fwrite(image[i], sizeof(RGBTRIPLE), width, outptr);

        // Escribe el relleno (padding) al final de la fila
        for (int k = 0; k < padding; k++)
        {
            fputc(0x00, outptr);
        }
    }

    // Libera la memoria de la imagen
    free(image);

    // Cierra los archivos
    fclose(inptr);
    fclose(outptr);
    return 0;
}