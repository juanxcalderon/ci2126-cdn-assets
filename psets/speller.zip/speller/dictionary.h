// Declara la funcionalidad de un diccionario

#ifndef DICTIONARY_H
#define DICTIONARY_H

#include <stdbool.h>

// Longitud máxima para una palabra
// (por ejemplo, pneumonoultramicroscopicsilicovolcanoconiosis)
#define LENGTH 45

// Prototipos
bool check(const char *word);
unsigned int hash(const char *word);
bool load(const char *dictionary);
unsigned int size(void);
bool unload(void);

#endif // DICTIONARY_H